package runner;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import pages.BankAccountDetailsPage;
import pages.FindYourBankPage;
import pages.BankAccountsPage;
import pages.HomePage;
import pages.LoginPage;
import app.constants.Constants;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddAccountSteps {
	WebDriver driver = null;
	LoginPage loginPage = null;
	HomePage homePage = null;
	BankAccountsPage bankAccountsPage = null; 
	FindYourBankPage findYourBankPage = null;
	BankAccountDetailsPage accountDetailsPage = null;
	static String timestamp = System.currentTimeMillis()+" ";

	@Before
	public void setUp(){
		String userdir = System.getProperty("user.dir").replace("\\", "/");
		System.setProperty("webdriver.chrome.driver", userdir+"/tools/chromedriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
		ChromeOptions opts = new ChromeOptions();
		opts.addArguments("start-maximized");
		capabilities.setCapability(ChromeOptions.CAPABILITY, opts);
		driver = new ChromeDriver(capabilities);
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	@Given("^I am on login page of Xero$")
	public void i_am_on_login_page_of_Xero() throws Throwable {
		String xeroUrl = Constants.URL;
		driver.get(xeroUrl);
		loginPage = new LoginPage(driver);
		boolean status = Constants.TITLE_LOGIN.equals(driver.getTitle());
		Assert.assertTrue("TITLE OF LOGIN PAGE IS INCORRECT", status);
	}

	@Given("^I login with credentials$")
	public void i_login_with_credentials(DataTable dataTable) throws Throwable {
		Map<String, String> dataMap = dataTable.asMap(String.class, String.class);
		loginPage.enterCredentials(dataMap);
		homePage = loginPage.clickLogin();
		boolean status = Constants.TITLE_HOME.equals(driver.getTitle());
		Assert.assertTrue("TITLE OF HOME PAGE IS INCORRECT", status);
	}

	@Given("^I go to Accounts$")
	public void i_go_to_Accounts() throws Throwable {
		homePage.clickAccounts();
	}

	@Given("^I go to Bank Accounts$")
	public void i_go_to_Bank_Accounts() throws Throwable {
		bankAccountsPage = homePage.selectMenuBankAccounts();
		boolean statusBankAccounts = Constants.TITLE_BANK_ACCOUNTS.equals(driver.getTitle());
		Assert.assertTrue("TITLE OF BANK ACCOUNTS PAGE IS INCORRECT", statusBankAccounts);
		findYourBankPage = bankAccountsPage.clickAddBankAccount();
		boolean statusFindYourBank = Constants.TITLE_FIND_YOUR_BANK.equals(driver.getTitle());
		Assert.assertTrue("TITLE OF FIND YOUR BANK PAGE IS INCORRECT", statusFindYourBank);
	}

	@When("^I add Bank Account$")
	public void i_add_Bank_Account(DataTable dataTable) throws Throwable {
		Map<String, String> dataMap = dataTable.asMap(String.class, String.class);
		accountDetailsPage = findYourBankPage.selectBank(dataMap);
	}

	@When("^I enter bank details$")
	public void i_enter_bank_details(DataTable dataTable) throws Throwable {
		Map<String, String> dataMap = dataTable.asMap(String.class, String.class);
		accountDetailsPage.enterBankAccountDetails(dataMap, timestamp);
		bankAccountsPage = accountDetailsPage.clickOnContinue(bankAccountsPage);
	}

	@Then("^I should see following success message$")
	public void i_should_see_following_success_message(DataTable dataTable) throws Throwable {
		Map<String, String> dataMap = dataTable.asMap(String.class, String.class);
		String expectedMessage = timestamp + dataMap.get("message");
		String actualMessage = bankAccountsPage.validateSuccessMessage();
		boolean status = expectedMessage.equals(actualMessage);
		Assert.assertTrue("THE SUCCESS MESSAGE FOR ADD BANK ACCOUNT DETAILS IS NOT AS EXPECTED", status);		
	}

	@After 
	public void cleanUp(){ 
		driver.close(); 
	} 
}
