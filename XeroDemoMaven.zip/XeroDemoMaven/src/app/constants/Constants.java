package app.constants;

public class Constants {
	public static final String URL = "https://login.xero.com/";
	
	//Titles of the pages
	public static final String TITLE_LOGIN = "Login | Xero Accounting Software";
	public static final String TITLE_HOME = "Xero | Dashboard | Test";
	public static final String TITLE_BANK_ACCOUNTS = "Xero | Bank Accounts | Test";
	public static final String TITLE_FIND_YOUR_BANK = "Xero | Find your bank | Test";
	public static final String TITLE_BANK_ACCOUNT_DETAILS = "Xero | Enter your ANZ (NZ) account details | Test";
}
