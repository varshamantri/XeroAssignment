package pages;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage{
	public WebDriver driver;
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}
	@FindBy(id="email")
	private WebElement txtUsername;
	@FindBy(id="password")
	private WebElement txtPassword;
	@FindBy(id="submitButton")
	private WebElement btnSubmit;
	
	/**
	 * This method is used to enter the login credentials of the user
	 * @param dataMap
	 */
	public void enterCredentials(Map<String, String> dataMap) {
		String username = dataMap.get("username");
		String password = dataMap.get("password");
		txtUsername.clear();
		txtUsername.sendKeys(username);
		txtPassword.clear();
		txtPassword.sendKeys(password);
	}
	
	/**
	 * This method is used to login the user to the Home Page
	 * @return HomePage
	 */
	public HomePage clickLogin() {
		btnSubmit.click();
		return new HomePage(driver);
	}
}
