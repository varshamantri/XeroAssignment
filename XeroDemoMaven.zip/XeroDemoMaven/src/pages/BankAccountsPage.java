package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BankAccountsPage {
	public WebDriver driver;
	WebDriverWait wait;
	public BankAccountsPage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, 5);
		PageFactory.initElements(this.driver, this);
	}
	@FindBy(css="[data-automationid='Add Bank Account-button']")
	private WebElement btnAddBankAccount;
	@FindBy(css="div.message p")
	private WebElement lblMessage;

	/**
	 * This method is used to navigate to the Add Bank Accounts Page 
	 * @return FindYourBankPage
	 */
	public FindYourBankPage clickAddBankAccount() {
		btnAddBankAccount.click();
		return new FindYourBankPage(driver);
	}

	/**
	 * This method is used to validate the success message that is displayed
	 * after adding the bank account details
	 * @return String
	 */
	public String validateSuccessMessage() {
		wait.until(ExpectedConditions.visibilityOf(lblMessage));
		String actualMessage = null;
		actualMessage = lblMessage.getText();
		return actualMessage;
	}
}
