package pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import app.constants.Constants;

public class FindYourBankPage {
	public WebDriver driver;
	WebDriverWait wait;
	public FindYourBankPage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, 5);
		PageFactory.initElements(this.driver, this);
	}
	@FindBy(css="li.ba-banklist--item.xui-contentblock--item")
	private List<WebElement> lstBankAccounts;
	
	/**
	 * This method is used to select the required bank from the list of 
	 * Popular New Zealand Banks
	 * @param dataMap 
	 * @return BankAccountDetailsPage
	 */
	public BankAccountDetailsPage selectBank(Map<String, String> dataMap) {
		String bankName = dataMap.get("bank");
		for(WebElement bank:lstBankAccounts) {
			if(bank.getText().equals(bankName)) {
				bank.click();
				break;
			}
		}
		wait.until(ExpectedConditions.titleContains(Constants.TITLE_BANK_ACCOUNT_DETAILS));
		return new BankAccountDetailsPage(driver);
	}
}
